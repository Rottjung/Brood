import React from "react";
import ReactDOM from "react-dom/client";
import BakeryPlanner from "./App";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<BakeryPlanner />);
